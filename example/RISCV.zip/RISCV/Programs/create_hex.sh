#!/bin/bash
python3 ../RISCV-RV32I-Assembler/src/rvi.py store.s --hex -o store.hex

