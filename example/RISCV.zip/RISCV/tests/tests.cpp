//
// Created by tobias on 11.04.17.
//
#include <gtest/gtest.h>

#include "ISA_tests.h"

int main(int argc, char **argv) {
    testing::InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}